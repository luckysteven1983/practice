'''
Created on Jan 27, 2018

@author: dadl
'''

class cleanUp(object):
    '''
    classdocs
    '''


    def __init__(self, params):
        '''
        Constructor
        '''
        
    def heatCleanupStageStack(self):
        pass
    
    def heatCleanupTargetStack(self):
        pass
    
    def heatCleanupCBAMStack(self):
        pass
    
    def heatCleanupCBAMvnf(self):
        pass
    
    def heatCleanupCBAMvnfpkg(self):
        pass
    
    def heatCleanupStageSnapshot(self):
        pass
    
    def heatCleanupCommonImage(self):
        pass