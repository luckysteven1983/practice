#!/bin/bash

# usage: handler_heal_healable_shell.sh "username" "password" "tenantName" "domain" "keystoneUrl" "region" "providerType" -t xxx -r xxx

WORKPATH=`dirname $0`
HealingPython="${WORKPATH}/handler_heal_healable_python.py"
[ -e $HealingPython ] || HealingPython="/tmp/ansible_shell/handler_heal_healable_python.py"
[ -e $HealingPython ] || HealingPython="/tmp/handler_heal_healable_python.py"
[ -e $HealingPython ] || { echo "Not found $HealingPython. Exit 1"; exit 1; }

# if running on pilot, and want to use 'os_run' to setup keystone authorization, set using_os_run=1
using_os_run=0
[ ${using_os_run} -eq 1 ] && {
    shift 7
    opts=$@
    /opt/config/lib/os_run python $HealingPython $opts
    exit $?
}

typeset -l Type
# Export keystone(auth) information
[ -n "$1" ] && export OS_USERNAME="$1"
[ -n "$2" ] && export OS_PASSWORD="$2"
[ -n "$3" ] && export OS_TENANT_NAME="$3"
[ -n "$3" ] && export OS_PROJECT_NAME="$3"
[ -n "$4" ] && export OS_USER_DOMAIN_NAME="$4"
[ -n "$5" ] && export OS_AUTH_URL="$5"
[ -n "$6" ] && export OS_REGION_NAME="$6"
[ -n "$7" ] && providerType="$7"
[ -n "$9" ] && Type="$9"
[ -n "${11}" ] && ResourceId="${11}"
[ -n "${12}" ] && ImageId="${12}"

[ -z "$ImageId" ] && ImageId="null"
opts="-t $Type -r $ResourceId -i $ImageId"
    
# /opt/nokia/mistral/venv/bin/activate only availabe in CBAM
optActivate="/opt/nokia/mistral/venv/bin/activate"
[ -e $optActivate ] && source $optActivate

[ -e /etc/psp/os_cacert ] && export OS_CACERT="/etc/psp/os_cacert"
    
# execute mcasHealing.py
if [ -e $optActivate ]; then
    python $HealingPython $opts
    exit $?
else
    rtmsg=`python $HealingPython $opts`
    rc=$?

    result="finished"
    [ $rc -ne 0 ] && result="failed"

    if [ "$Type" == "reboot" -o "$Type" == "rebuild" ]; then
        jsStr='{"result":"'$result'","detail":"'$rtmsg'"}'
    else
        uuid=$(echo $rtmsg | awk -F':' '{print $NF}')
    
        if [[ -z $uuid ]]; then
            jsStr='{"result":"'$result'","detail":"'$rtmsg'","uuid":""}'
        else
            jsStr='{"result":"'$result'","detail":"'$rtmsg'","uuid":"'$uuid'"}'
        fi
    fi

    echo $jsStr
    exit $rc
fi

exit 0


