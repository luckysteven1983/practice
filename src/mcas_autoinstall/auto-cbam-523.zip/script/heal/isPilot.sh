#!/bin/ksh

vmId=$1
[ -z $vmId ] && { echo "No VM uuid input."; exit 2; }
echo "VM uuid: $vmId"

clientMap=/opt/config/conf/vm/client.map
[ -f $clientMap ] || { echo "Not found $clientMap."; exit 2; }

myrcs=`grep -w $vmId /opt/config/conf/vm/client.map | awk '{print $1}'`
[ -z $myrcs ] && { echo "Failed to get valid rcs from client.map."; exit 2; }

pilotrcs=`/opt/config/lib/get_pilot_RCS`
[ -z $pilotrcs ] && { echo "Failed to get pilot rcs list."; exit 2; }

for rcs in $pilotrcs
do
    [ "$myrcs" == "$rcs" ] && { echo "RCS is $myrcs, and this is a pilot."; exit 0; }
done

echo "RCS is $myrcs, and this is a non-pilot."
exit 1

