#!/usr/bin/env python
###############################################################################
##                                                                           ##
##             CONFIDENTIAL. All rights reserved. Nokia.                     ##
##             This computer program is protected under Copyright.           ##
##             Recipient is to retain the program in confidence, and         ##
##             is not permitted to copy, use, distribute, modify             ##
##             or translate the program without authorization.               ##
##                                                                           ##
###############################################################################

import os, sys, time
import getopt   
import datetime
import logging
import logging.handlers
import filecmp
from novaclient import client as nvclient
from cinderclient import client as cdclient
from neutronclient.neutron import client as ntclient
try:
    from keystoneauth1 import session
except Exception, e:
    from keystoneclient import session

try:
    import requests
    from requests.packages.urllib3.exceptions import InsecureRequestWarning
    requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
except Exception, e:
    pass


class CbamHealing():

    Healing_Path = "/tmp/mcasHealing"
    Status_Path = Healing_Path+"/Status"
    Log_File = Healing_Path +"/healing.log"

    NOVA_VERSION = "2"
    CINDER_VERSION = "2"
    NEUTRON_VERSION = "2.0"

    L_Timeout = 300

    Debug = True
    Healing_Logger = None
    Log_Size = 10*1024*1024
    Log_Num = 1
    NORMAL_MSG = ""
    ERROR_MSG = ""
    

    def  __init__(self):
        if not os.path.exists(self.Healing_Path):
            os.mkdir(self.Healing_Path)
        if not os.path.exists(self.Log_File):
            os.mknod(self.Log_File, 0777)

        if self.Healing_Logger == None:
            self.Healing_Logger = self.init_logger()

    def initOpenstackClient(self):
        sess = self.get_keystone_session()
        if sess == None:
            return None

        self.nova = nvclient.Client(self.NOVA_VERSION, session=sess)
        #print self.nova.servers.list()

        self.cinder = cdclient.Client(self.CINDER_VERSION, session=sess)
        #print self.cinder.volumes.list()

        self.neutron = ntclient.Client(self.NEUTRON_VERSION, session=sess)
        #print self.neutron.list_networks()

        return sess

    @staticmethod
    def init_logger():
        my_logger = logging.getLogger('CbamHealing')
        if len(my_logger.handlers):
            return my_logger

        my_logger.setLevel(logging.DEBUG)
        handler = logging.handlers.RotatingFileHandler(CbamHealing.Log_File, maxBytes=CbamHealing.Log_Size, backupCount=CbamHealing.Log_Num)
        formatter = logging.Formatter('%(asctime)s - %(message)s')
        handler.setFormatter(formatter)
        my_logger.addHandler(handler)

        if CbamHealing.Debug:
            console_handler = logging.StreamHandler(sys.stdout)
            console_handler.setFormatter(formatter)
            my_logger.addHandler(console_handler)
        
        return my_logger
        

    def log(self, msg):
        if msg.find("Error:") == -1:
            self.NORMAL_MSG = "%s\n%s" % (self.NORMAL_MSG, msg) 
            self.Healing_Logger.info(msg)
        else:
            self.ERROR_MSG = msg
            self.Healing_Logger.error(msg)

    def get_keystone_session(self):
        if 'OS_AUTH_URL' not in os.environ or os.environ['OS_AUTH_URL'] == '':
            self.log("Error: OS_AUTH_URL not set or empty.")
            return None

        ks_version = os.environ['OS_AUTH_URL'].rstrip('/').split('/')[-1].lower()
        if ks_version == "v2.0":
            try:
                from keystoneauth1.identity import v2 as ksv
            except Exception, e:
                from keystoneclient.auth.identity import v2 as ksv
        elif ks_version == "v3":
            try:
                from keystoneauth1.identity import v3 as ksv
            except Exception, e:
                from keystoneclient.auth.identity import v3 as ksv
        else:
            return None

        if not self.validate_auth(ks_version):
            return None
        creds = self.get_ks_creds(ks_version)
        auth = ksv.Password(**creds)
        sess = session.Session(auth=auth, verify=False)

        return sess

    def validate_auth(self, ksversion):
        # Check whether all mandatory parameters are input
        if ksversion == "v2.0":
            mandatory_para_list = ['OS_USERNAME', 'OS_PASSWORD', 'OS_AUTH_URL', 'OS_TENANT_NAME']
        elif ksversion == "v3":
            mandatory_para_list = ['OS_USERNAME', 'OS_PASSWORD', 'OS_AUTH_URL', 'OS_USER_DOMAIN_NAME']
        
        para_valid = True
        for para in mandatory_para_list:
            if para not in os.environ or os.environ[para] == '':
                self.log("Error: %s not set or empty." % para)
                para_valid = False
        
        return para_valid
            
    def get_ks_creds(self, ksversion):
        creds = {}
        creds['username'] = os.environ['OS_USERNAME']
        creds['password'] = os.environ['OS_PASSWORD']
        creds['auth_url'] = os.environ['OS_AUTH_URL']

        if ksversion == "v2.0":
            creds['tenant_name'] = os.environ['OS_TENANT_NAME']
        elif ksversion == "v3":
            if 'OS_PROJECT_NAME' in os.environ:
                creds['project_name'] = os.environ['OS_PROJECT_NAME']
            elif 'OS_PROJECT_ID' in os.environ:
                creds['project_name'] = os.environ['OS_PROJECT_ID']
            else:
                creds['project_name'] = os.environ['OS_TENANT_NAME']

            if 'OS_USER_DOMAIN_NAME' in os.environ:
                creds['user_domain_name'] = os.environ['OS_USER_DOMAIN_NAME']
                if 'OS_PROJECT_NAME' in os.environ:
                    creds['project_domain_name'] = os.environ['OS_USER_DOMAIN_NAME']
            elif 'OS_USER_DOMAIN_ID' in os.environ:
                creds['user_domain_id'] = os.environ['OS_USER_DOMAIN_ID']
                if 'OS_PROJECT_ID' in os.environ:
                    creds['project_domain_id'] = os.environ['OS_USER_DOMAIN_ID']

        return creds

    # reboot one specific server, mode = "SOFT" or "HARD"
    def nova_reboot(self, server_id, mode="SOFT", nowait=False):
        self.log("Nova reboot %s started." % server_id)
        try:
            server = self.nova.servers.find(id=server_id)
            rebootMode = mode
            if self.nova.servers.get(server_id).status != "ACTIVE":
                rebootMode = "HARD"
            server.reboot(rebootMode)
            if nowait:
                return 0

            time_out = self.L_Timeout
            while True:
                if self.nova.servers.get(server_id).status == "ACTIVE":
                    self.log("%s has been become ACTIVE. Nova reboot %s is successful." % (server_id, server_id))
                    return 0
                time.sleep(2)
                time_out = time_out-2
                if time_out <= 0:
                    self.log("Error: %s failed to become ACTIVE. Nova reboot %s failed." % (server_id, server_id))
                    return 1
        except Exception, e:
            self.log("Error: %s. Nova reboot %s failed." % (e, server_id))
            return 1

        return 0


    # rebuild one specific server
    def nova_rebuild(self, server_id, imageId=""):
        self.log("Nova rebuild %s started." % server_id)
        try:
            server = self.nova.servers.find(id=server_id)
            if imageId == "":
                image = server.image['id']
            else:
                try:
                    image = self.nova.images.find(name=imageId)
                except Exception, e:
                    try:
                        image = self.nova.images.find(id=imageId)
                    except Exception, e:
                        self.log("Error: Failed to find image or find more than one image whose name or ID is %s. Nova rebuild %s failed." % (imageId, server_id))
                        return 1
            server.rebuild(image)

            time_out = self.L_Timeout*3
            while True:
                if self.nova.servers.get(server_id).status != "REBUILD":
                    self.log("%s rebuild is done. Nova rebuild %s is successful." % (server_id, server_id))
                    return 0
                time.sleep(2)
                time_out = time_out-2
                if time_out <= 0:
                    self.log("Error: %s failed to complete rebuild. Nova rebuild %s failed." % (server_id, server_id))
                    return 1
        except Exception, e:
            self.log("Error: %s. Nova rebuild %s failed." % (e, server_id))
            return 1

        return 0


    # stop nova instance
    def nova_stop_instance(self, server_id):
        self.log("Nova stop %s started." % server_id)
        try:
            if self.nova.servers.get(server_id).status == "SHUTOFF":
                self.log("%s is already in vm_state stopped." % server_id)
                return 0
            self.nova.servers.stop(server_id)
            time_out = self.L_Timeout*2
            while True:
                if self.nova.servers.get(server_id).status == "SHUTOFF":
                    self.log("%s has been stopped. Nova stop %s is successful." % (server_id, server_id))
                    return 0
                time.sleep(2)
                time_out = time_out-2
                if time_out <= 0:
                    self.log("Error: %s failed to be stopped. Nova stop %s failed." % (server_id, server_id))
                    return 1
        except Exception, e:
            self.log("Error: %s. Nova stop %s failed." % (e, server_id))
            return 1

        return 0

    # start nova instance
    def nova_start_instance(self, server_id):
        self.log("Nova start %s started." % server_id)
        try:
            if self.nova.servers.get(server_id).status == "ACTIVE":
                self.log("%s is already in state ACTIVE." % server_id)
                return 0
            self.nova.servers.start(server_id)
            time_out = self.L_Timeout*2
            while True:
                if self.nova.servers.get(server_id).status == "ACTIVE":
                    self.log("%s has been become ACTIVE. Nova start %s is successful." % (server_id, server_id))
                    return 0
                time.sleep(2)
                time_out = time_out-2
                if time_out <= 0:
                    self.log("Error: %s failed to become ACTIVE. Nova start %s failed." % (server_id, server_id))
                    return 1
        except Exception, e:
            self.log("Error: %s. Nova start %s failed." % (e, server_id))
            return 1

        return 0

    # attach volume to sever
    def nova_attach_volume(self, server_id, volume_id, multiattach=False):
        self.log("Nova attach volume %s to server %s started." % (volume_id, server_id))
        try:
            self.nova.volumes.create_server_volume(server_id, volume_id, None)

            # check whether new volume has been attached
            time_out = self.L_Timeout
            while True:
                if multiattach:
                    if len(self.cinder.volumes.get(volume_id).attachments) == 2:
                        self.log("Multiattach volume %s has been attached to %s." % (volume_id, server_id))
                        break
                else:
                    if self.cinder.volumes.get(volume_id).status == "in-use":
                        self.log("%s has been attached to %s." % (volume_id, server_id))
                        break
                time.sleep(2)
                time_out = time_out-2
                if time_out <= 0:
                    self.log("Error: %s failed to be attached to %s." % (volume_id, server_id))
                    return 1
        except Exception, e:
            self.log("Error: %s. %s failed to be attached to %s." % (e, volume_id, server_id))
            return 1

        return 0

    # detach volume from sever
    def nova_detach_volume(self, server_id, volume_id, multiattach=False):
        self.log("Nova detach volume %s from server %s started." % (volume_id, server_id))
        try:
            self.nova.volumes.delete_server_volume(server_id, volume_id)
            time_out = self.L_Timeout
            while True:
                if multiattach:
                    if len(self.cinder.volumes.get(volume_id).attachments) == 1:
                        self.log("Multiattach volume %s has been detached from %s." % (volume_id, server_id))
                        break
                else:
                    if self.cinder.volumes.get(volume_id).status == "available":
                        self.log("%s has been detached from %s." % (volume_id, server_id))
                        break
                time.sleep(2)
                time_out = time_out-2
                if time_out <= 0:
                    self.log("Error: %s failed to be detached from %s." % (volume_id, server_id))
                    return 1
        except Exception, e:
            self.log("Error: %s. %s failed to be detached from %s." % (e, volume_id, server_id))
            return 1

        return 0

    # create volume
    def cinder_create_volume(self, vol_name, vol_size, multiattach=False, vol_type=None):
        self.log("Cinder create volume started.")
        try:
            if multiattach:
                newvol = self.cinder.volumes.create(name=vol_name, size=vol_size, multiattach=True, volume_type=vol_type)
            else:
                newvol = self.cinder.volumes.create(name=vol_name, size=vol_size)
            time_out = self.L_Timeout
            while True:
                try:
                    if self.cinder.volumes.get(newvol.id).status == "available":
                        self.log("%s has been created and available." % newvol.id)
                        break
                    elif self.cinder.volumes.get(newvol.id).status == "error":
                        self.log("Error: Failed to create a new volume.")
                        return None
                except Exception, e:
                    pass
                time.sleep(2)
                time_out = time_out-2
                if time_out <= 0:
                    self.log("Error: Failed to create a new volume.")
                    return None
                    break
        except Exception, e:
            self.log("Error: %s. Failed to create a new volume." % e)
            return None

        return newvol

    # delete volume
    def cinder_delete_volume(self, vol, volume_id):
        self.log("Cinder delete %s volume started." % volume_id)
        try:
            volsize = vol.size
            self.cinder.volumes.delete(vol)
            time_out = max(int(volsize)/1000*self.L_Timeout, self.L_Timeout)
            while True:
                try:
                    self.cinder.volumes.get(volume_id)
                except Exception, e:
                    self.log("%s has been deleted." % volume_id)
                    break
                time.sleep(2)
                time_out = time_out-2
                if time_out <= 0:
                    self.log("Error: %s failed to be deleted." % volume_id)
                    return 1
        except Exception, e:
            self.log("Error: %s. %s failed to be deleted." % (e, volume_id))
            return 1

        return 0

    # convert nova port list to port id list
    def convert_nova_portlist(self, val):
        portid_list = []
        for p in val:
            portid_list.append(p.id)

        return portid_list

    # convert neutron port list to port id list
    def convert_neutron_portlist(self, val, type="port"):
        portid_list = []
        val_list = val['ports']
        for p in val_list:
            for k, v in p.items():
                if k == "id":
                    portid_list.append(v)

        return portid_list

    # check whether specific port is attached onto the server
    def nova_port_attached(self, server, port_id):
        server_id = server.id
        self.log("Check whether port %s is attached to %s started." % (port_id, server_id))
        try:
            if not port_id in self.convert_nova_portlist(server.interface_list()):
                msg = "%s not exists or not attached onto %s." % (port_id, server_id)
                self.log(msg)
                return 1                
        except Exception, e:
            msg = "%s not exists or not attached onto %s." % (port_id, server_id)
            self.log(msg)
            return 1
        
        msg = "%s is attached onto %s." % (port_id, server_id)
        self.log(msg)
        return 0
 
    # detach port from sever
    def nova_detach_port(self, server, port_id):
        server_id = server.id
        self.log("Nova detach port %s from server %s started." % (port_id, server_id))
        try:
            server.interface_detach(port_id)
            time_out = self.L_Timeout
            while True:
                if self.nova_port_attached(server, port_id) != 0:
                    msg = "%s has been detached from %s." % (port_id, server_id)
                    self.log(msg)
                    break
                time.sleep(2)
                time_out = time_out-2
                if time_out <= 0:
                    msg = "Error: %s failed to be detached from %s." % (port_id, server_id)
                    self.log(msg)
                    return 1
        except Exception, e:
            msg = "Error: %s. %s failed to be detached from %s." % (e, port_id, server_id)
            self.log(msg)
            return 1

        return 0

    # attach port to sever
    def nova_attach_port(self, server, port):
        server_id = server.id
        self.log("Nova attach new port to server %s started." % server_id)
        try:
            port_id = port['port']['id']

            server.interface_attach(port_id, None, None)
            time_out = self.L_Timeout
            while True:
                if self.nova_port_attached(server, port_id) == 0:
                    msg = "%s has been attached to %s." % (port_id, server_id)
                    self.log(msg)
                    break
                time.sleep(2)
                time_out = time_out-2
                if time_out <= 0:
                    msg = "Error: %s failed to be attached to %s." % (port_id, server_id)
                    self.log(msg)
                    return 1
        except Exception, e:
            msg = "Error: %s. %s failed to be attached to %s." % (e, port_id, server_id)
            self.log(msg)
            return 1

        return 0
        
    # delete port
    def neutron_delete_port(self, port_id):
        self.log("Neatron delete port %s started." % port_id)
        try:
            self.neutron.delete_port(port_id)
            time_out = self.L_Timeout
            while True:
                try:
                    if not port_id in self.convert_neutron_portlist(self.neutron.list_ports()):
                        msg = "%s has been deleted." % port_id
                        self.log(msg)
                        break
                except Exception, e:
                    msg = "%s has been deleted." % port_id
                    self.log(msg)
                    break
                time.sleep(2)
                time_out = time_out-2
                if time_out <= 0:
                    msg = "Error: %s failed to be deleted." % port_id
                    self.log(msg)
                    return 1
        except Exception, e:
            msg = "Error: %s. %s failed to be deleted." % (e, port_id)
            self.log(msg)
            return 1

        return 0
        
    # create new port
    def neutron_create_port(self, port):
        self.log("Neatron create new port started.")
        try:
            body_value = port
            for key in ['status', 'dns_assignment', 'id', 'device_id']:
                if key in body_value['port']:
                    del body_value['port'][key]

            
            newport = self.neutron.create_port(body=body_value)
            port_id = newport['port']['id']
            
            time_out = self.L_Timeout
            while True:
                try:
                    if port_id in self.convert_neutron_portlist(self.neutron.list_ports()):
                        msg = "%s has been created and available." % port_id
                        self.log(msg)
                        return newport
                except Exception, e:
                    pass
                time.sleep(2)
                time_out = time_out-2
                if time_out <= 0:
                    msg = "Error: Failed to create a new port."
                    self.log(msg)
                    return None
                    break
        except Exception, e:
            msg = "Error: %s. Failed to create a new port." % e
            self.log(msg)
            return None

        return None
        
    # pre action before operation, including check whether previous operation is in progress
    # and clean up all flag files if this operation is valid to go
    def pre_action(self, htype, resource_id):
        # check whether previous healing has completed
        # if not completed, don't allow to do same healing again
        (status, msg) = self.get_healing_status(htype, resource_id)
        if status == "started":
            self.log("Last healing action is not completed yet. Do nothing.")
            return 0

        # clean up all status flag files
        if self.cleanup_flag(htype, resource_id) == False:
            self.log("Error: Failed to clean up flag files.")
            return 1

        return 2

    # build healing status flag name
    def build_flag_name(self, htype, resource_id):
        return "%s.%s" % (htype, resource_id)


    # set status flag by creating or updating status flag file
    def set_status_flag(self, htype, resource_id, status, msg=""):
        hname = self.build_flag_name(htype, resource_id) 
        flag_file = "%s/%s.%s" % (self.Status_Path, hname, status)

        if not os.path.exists(self.Status_Path): 
            os.mkdir(self.Status_Path)

        try:
            ff = open(flag_file, 'w')
            if msg != "":
                ff.write(msg)
            ff.close()
        except Exception, e:
            self.log("Error: Failed to set flag file %s." % flag_file)
            return 1

        return 0
        
    # get the status of healing
    def get_healing_status(self, htype, resource_id):
        hname = self.build_flag_name(htype, resource_id)
        started_flag = "%s/%s.started" % (self.Status_Path, hname)
        failed_flag = "%s/%s.failed" % (self.Status_Path, hname)
        success_flag = "%s/%s.success" % (self.Status_Path, hname)

        if os.path.exists(success_flag):
            return "Success", ""
        elif os.path.exists(failed_flag):
            msg = ""
            for line in open(failed_flag, 'r'):
                msg = msg + line
            return "Failed", msg
        elif os.path.exists(started_flag):
            cTimeout = 60*60
            if time.time() - os.path.getctime(started_flag) > cTimeout:
                return "Expired", ""
            return "Started", ""

        return "No Status found", ""

    # clean up all flag files as the preparation for new healing activity
    def cleanup_flag(self, htype, resource_id):
        hname = self.build_flag_name(htype, resource_id)
        started_flag = "%s/%s.started" % (self.Status_Path, hname)
        failed_flag = "%s/%s.failed" % (self.Status_Path, hname)
        success_flag = "%s/%s.success" % (self.Status_Path, hname)

        for ff in [started_flag, failed_flag, success_flag]:
            if os.path.exists(ff):
                os.remove(ff)

        return True
        
    # reboot server. Try SOFT reboot first, and if SOFT reboot fails, then try HARD reboot
    def reboot_server(self, server_id):
        htype = "reboot"

        # pre-action
        rt = self.pre_action(htype, server_id)
        if rt != 2:
            return rt
            
        # set started flag
        if self.set_status_flag(htype, server_id, "started") != 0:
            return 1
        
        if self.nova_reboot(server_id) != 0:
            self.log("Soft reboot failed. Try Hard reboot.")
            if self.nova_reboot(server_id, "HARD") != 0:
                return 1
        return 0

    # rebuild server
    def rebuild_server(self, server_id, image_id=""):
        htype = "rebuild"

        # pre-action
        rt = self.pre_action(htype, server_id)
        if rt != 2:
            return rt
            
        # set started flag
        if self.set_status_flag(htype, server_id, "started") != 0:
            return 1

        if self.nova_rebuild(server_id, image_id) != 0:
            return 1
        
        time.sleep(20)
        # check and start server if not started
        if self.nova_start_instance(server_id) != 0:
            return 1
                
        return 0

    # replace attached volume resource
    # return code: 0-success; 1-failed when replacing
    def replace_attached_volume(self, volume_id):
        try:
            newVolId = ''
            #server_id = self.nova.servers.find(name=server_name).id
            htype = "replace_attached_volume"

            # pre-action
            rt = self.pre_action(htype, volume_id)
            if rt != 2:
                return rt, newVolId
            # set started flag
            if self.set_status_flag(htype, volume_id, "started") != 0:
                return 1, newVolId

            # get the information of volume
            vol = self.cinder.volumes.get(volume_id)
            vol_name = vol.name
            vol_size = vol.size
            vol_attachments = vol.attachments
            if len(vol.attachments) == 0:
                self.log("Error: Volume %s not attaching to any server." % volume_id)
                return 1, newVolId
            server_id = vol_attachments[0]['server_id']
            if server_id == '':
                self.log("Error: Volume %s not attaching to any server." % volume_id)
                return 1, newVolId
            
            # check whether specific volume is attached onto the server
            try:
                self.nova.volumes.get_server_volume(server_id, volume_id)
            except Exception, e:
                self.log("Error: %s not exists or not attached onto %s." % (server_id, volume_id))
                return 1, newVolId

            #stop server
            if self.nova_stop_instance(server_id) != 0:
                return 1, newVolId

            # detach volume from sever
            if self.nova_detach_volume(server_id, volume_id) != 0:
                return 1, newVolId

            # create new volume with original name and size
            newvol = self.cinder_create_volume(vol_name, vol_size)
            newVolId = newvol.id
            if newvol == None:
                return 1, newVolId

            # attach volume to sever
            if self.nova_attach_volume(server_id, newvol.id) != 0:
                return 1, newVolId
                
            # delete volume
            if self.cinder_delete_volume(vol, volume_id) != 0:
                return 1, newVolId

            # rebuild server
            if self.nova_rebuild(server_id) != 0:
                return 1, newVolId

            # sleep a while before starting this server
            time.sleep(20)
            # start server
            if self.nova_start_instance(server_id) != 0:
                return 1, newVolId

        except Exception, e:
            self.log("Error: %s" % e)
            return 1, newVolId

        return 0, newVolId

    # replace switchable volume resource
    # return code: 0-success; 1-failed when replacing
    def replace_switchable_volume(self, volume_id):
        try:
            newVolId = ''
            htype = "replace_switchable_volume"

            # pre-action
            rt = self.pre_action(htype, volume_id)
            if rt != 2:
                return rt, newVolId
            # set started flag
            if self.set_status_flag(htype, volume_id, "started") != 0:
                return 1, newVolId

            # get the information of volume
            vol = self.cinder.volumes.get(volume_id)
            vol_name = vol.name
            vol_size = vol.size
            vol_attachments = vol.attachments
            if len(vol.attachments) == 0:
                self.log("Volume %s not attaching to any server." % volume_id)
            else:
                server_id = vol_attachments[0]['server_id']
                if server_id != '':
                    # detach volume from sever
                    if self.nova_detach_volume(server_id, volume_id) != 0:
                        return 1, newVolId

            # create new volume with original name and size
            newvol = self.cinder_create_volume(vol_name, vol_size)
            newVolId = newvol.id
            if newvol == None:
                return 1, newVolId
            
            # delete volume
            if self.cinder_delete_volume(vol, volume_id) != 0:
                return 1, newVolId
                
            self.log("New switchable cinder volume is %s." % newvol.id)
            
            # If replaced, update Switchable cinder volume_id in /etc/psp/shared_volid1.
            # Then start both pilots to see whether new switchable volume has been attached.

        except Exception, e:
            self.log("Error: %s" % e)
            return 1, newVolId

        return 0, newVolId
 
    # replace multi-attach volume resource
    # return code: 0-success; 1-failed when replacing
    def replace_multiattach_volume(self, volume_id, switchableVol = False):
        try:
            newVolId = ''
			
            if switchableVol:
                htype = "replace_switchable_volume"
            else:
                htype = "replace_attached_shared_volume"

            # pre-action
            rt = self.pre_action(htype, volume_id)
            if rt != 2:
                return rt, newVolId
            # set started flag
            if self.set_status_flag(htype, volume_id, "started") != 0:
                return 1, newVolId
            
            # if no_drbd is not enabled but it is replace_attached_shared_volume, return error
            if  htype == "replace_attached_shared_volume" and not self.is_no_drbd():
                self.log("Error: SI_NO_DRDB is not enabled. There is no attached_shared_volume.")
                return 1, newVolId

            # get the information of volume
            vol = self.cinder.volumes.get(volume_id)
            vol_name = vol.name
            vol_size = vol.size
            vol_type = vol.volume_type
            vol_attachments = vol.attachments
            if len(vol.attachments) != 2:
                self.log("Error: Volume %s is not attaching to two servers." % volume_id)
                return 1, newVolId
            server1_id = vol_attachments[0]['server_id']
            server2_id = vol_attachments[1]['server_id']
            
            self.log("1st server id of multiattach volume: %s" % server1_id)
            self.log("2nd server id of multiattach volume: %s" % server2_id)
            
            for server_id in [server1_id, server2_id]:
                # check whether specific volume is attached onto the server
                try:
                    self.nova.volumes.get_server_volume(server_id, volume_id)
                except Exception, e:
                    self.log("Error: %s not exists or not attached onto %s." % (server_id, volume_id))
                    return 1, newVolId

            # detach volume from 2 severs one by one
            if self.nova_detach_volume(server1_id, volume_id, True) != 0:
                return 1, newVolId
            if self.nova_detach_volume(server2_id, volume_id) != 0:
                return 1, newVolId

            # Don't delete volume at this point, but do that after new volume is attached
            #if self.cinder_delete_volume(vol, volume_id) != 0:
            #    return 1, newVolId

            # create new volume with original name and size
            newvol = self.cinder_create_volume(vol_name, vol_size, True, vol_type)
            newVolId = newvol.id
            if newvol == None:
                return 1, newVolId

            # attach volume to 2 severs one by one
            if self.nova_attach_volume(server1_id, newvol.id) != 0:
                return 1, newVolId
            if self.nova_attach_volume(server2_id, newvol.id, True) != 0:
                return 1, newVolId
            
            # delete volume
            if self.cinder_delete_volume(vol, volume_id) != 0:
                return 1, newVolId
            
            # reboot server when not switchable volume
            if not switchableVol:
                # reboot mated pilot first, and then reboot self
                if self.get_vmid() == server1_id:
                    server1_id, server2_id = server2_id, server1_id
                for server_id in [server1_id, server2_id]:
                    if self.nova_reboot(server_id, "HARD", True) != 0:
                        return 1, newVolId

        except Exception, e:
            self.log("Error: %s" % e)
            return 1, newVolId

        return 0, newVolId
        
    # replace port
    def replace_port(self, port_id):
        try:
            htype = "replace_port"

            # pre-action
            rt = self.pre_action(htype, port_id)
            if rt != 2:
                return rt
            # set started flag
            if self.set_status_flag(htype, port_id, "started") != 0:
                return 1

            # get the information of existing port 
            port = self.neutron.show_port(port_id)
            try:
                server_id = port['port']['device_id']
            except Exception, e:
                self.log("Error: Port %s not attaching to any server." % volume_id)
                return 1
            if server_id == '':
                self.log("Error: Port %s not attaching to any server." % volume_id)
                return 1
            
            server = self.nova.servers.get(server_id)
            # check whether specific port is attached onto the server
            if self.nova_port_attached(server, port_id) != 0:
                return 1

            # stop server
            if self.nova_stop_instance(server_id) != 0:
                return 1


            # detach port from sever
            if self.nova_detach_port(server, port_id) != 0:
                return 1

            # delete port
            if self.neutron_delete_port(port_id) != 0:
                return 1

            # create new port with the configuration of original port
            newport = self.neutron_create_port(port)
            if newport == None:
                return 1

            # attach port to sever
            if self.nova_attach_port(server, newport) != 0:
                return 1

            time.sleep(20)
            # start server
            if self.nova_start_instance(server_id) != 0:
                return 1

        except Exception, e:
            self.log("Error: %s" % e)
            return 1

        return 0

    # replace server. Not used
    def replace_server(self, server_id):
        htype = "replace_server"

        # pre-action
        rt = self.pre_action(htype, server_id)
        if rt != 2:
            return rt

        # set started flag
        if self.set_status_flag(htype, server_id, "started") != 0:
            return 1

        if self.nova_rebuild(server_id) != 0:
            return 1

        return 0

    # Check whether no_drbd is enabled
    def is_no_drbd(self):
        nodrbdScript = "/opt/config/lib/is_no_drbd"
        if not os.path.exists(nodrbdScript):
            return True
        elif os.system("sudo %s" % nodrbdScript) == 0:
            return True
            
        return False
        
    # Check whether multiattach is enabled
    def is_multiattach(self):
        cloudconf = "/opt/config/conf/vm/cloud.conf"
        if os.path.exists(cloudconf) and os.system("sudo grep \"^switchable-cinder-multiattach=yes\" %s > /dev/null" % cloudconf) == 0:
            return True
            
        return False

    # Get self vmid from /etc/psp/vmid
    def get_vmid(self):
        vmid = None
        vmidfile = "/etc/psp/vmid"
        if os.path.exists(vmidfile):
            return open(vmidfile).read().strip('\n')
            
        return vmid


# Main
if __name__ == '__main__':

    shortOpt="hi:r:t:S"
    TYPE = ""
    Server_Id = ""
    Resource_Id = ""
    Image_Id = ""
    Check_Status = False
    VALID_TYPE = ["reboot", "rebuild", "rebuildonly",
                    "replace_attached_volume", "replace_switchable_volume", "replace_attached_shared_volume"]

    def usage(rtcode=0):
        print "Usage: ./handler_heal_healable_python.py -%s" % shortOpt
        print "    ./handler_heal_healable_python.py -t <TYPE> -r <uuid of VM or Resource>" % VALID_TYPE
        #print "    ./handler_heal_healable_python.py -S -t <TYPE> -r <uuid of VM or Resource>"
        print "     -h   Display usage information."
        print "     -t   Healing type. Valid types are \n       %s" % VALID_TYPE
        print "     -r   Resource ID, the uuid of resource(server) to be healed."
        #print "     -S   Show the status of one specified healing operation."
        print """Example:
    ./handler_heal_healable_python.py -t reboot -r 266de114-e88c-4eba-b961-73407d2e54ed
    ./handler_heal_healable_python.py -t rebuild -r 266de114-e88c-4eba-b961-73407d2e54ed
    ./handler_heal_healable_python.py -t rebuildonly -r 266de114-e88c-4eba-b961-73407d2e54ed
    ./handler_heal_healable_python.py -t replace_attached_volume -r 1f8a53c2-5b98-46fd-8aa4-7a52e3b4d7db
    ./handler_heal_healable_python.py -t replace_switchable_volume -r 1f8a53c2-5b98-46fd-8aa4-7a52e3b4d7db
    ./handler_heal_healable_python.py -t replace_attached_shared_volume -r 1f8a53c2-5b98-46fd-8aa4-7a52e3b4d7db"""
        sys.exit(rtcode)

    def strResultMsg(Result, TYPE, Resource_Id, newResource_Id=None):
        if newResource_Id == None:
            return "%s:%s:%s" % (Result, TYPE, Resource_Id)
        else:
            return "%s:%s:%s:%s" % (Result, TYPE, Resource_Id, newResource_Id)

    try:
        opts, args = getopt.getopt(sys.argv[1:], shortOpt)
        for opt, val in opts:
            if opt == "-h":
                usage()
            elif opt == "-i":
                if val.strip() != '' and val.strip() != 'null':
                    Image_Id = val
            elif opt == "-t":
                TYPE = val.lower()
            elif opt == "-r":
                Resource_Id = val
            elif opt == "-S":
                Check_Status = True
    except Exception, e:
        print e
        print "Error: Wrong option input. Please check by ./handler_heal_healable_python.py -h "
        sys.exit(1)

    if TYPE not in VALID_TYPE:
        print "Error: Wrong type input. Correct '-t' option is %s" % VALID_TYPE
        print strResultMsg("Error", TYPE, Resource_Id)
        sys.exit(1)

    if Resource_Id == "":
        print "Error: -r <Resource_Id> must be input."
        print strResultMsg("Error", TYPE, Resource_Id)
        sys.exit(1)

    try:
        ch = CbamHealing()
    except Exception, e:
        print "Error: %s" % e
        print strResultMsg("Error", TYPE, Resource_Id)
        sys.exit(1)
        
    try:
        new_vol = None
        if ch.initOpenstackClient() == None:
            ch.log("Error: Keystone authorization failed.")
            ch.set_status_flag(TYPE, Resource_Id, "failed", ch.ERROR_MSG)
            rtmsg = strResultMsg("Error", TYPE, Resource_Id)
            ch.log(rtmsg)
            sys.exit(1)

        if Check_Status:
            status, msg = ch.get_healing_status(TYPE, Resource_Id)
            print "%s: %s" % (status, msg)
            sys.exit(0)

        rt_code = 0
        if TYPE == "reboot":
            rt_code = ch.reboot_server(Resource_Id)
        elif TYPE == "rebuild" or TYPE == "rebuildonly":
            rt_code = ch.rebuild_server(Resource_Id, Image_Id)
        elif TYPE == "replace_port":
            rt_code = ch.replace_port(Resource_Id)
        elif TYPE == "replace_attached_volume":
            (rt_code, new_vol) = ch.replace_attached_volume(Resource_Id)
        elif TYPE == "replace_switchable_volume":
            if ch.is_multiattach():
                (rt_code, new_vol) = ch.replace_multiattach_volume(Resource_Id, True)
            else:
                (rt_code, new_vol) = ch.replace_switchable_volume(Resource_Id)
        elif TYPE == "replace_attached_shared_volume":
            (rt_code, new_vol) = ch.replace_multiattach_volume(Resource_Id)

        if rt_code == 0:
            ch.set_status_flag(TYPE, Resource_Id, "success", ch.NORMAL_MSG)
            rtmsg = strResultMsg("Success", TYPE, Resource_Id, new_vol)
            ch.log(rtmsg)
            sys.exit(0)
        else:
            ch.set_status_flag(TYPE, Resource_Id, "failed", ch.ERROR_MSG)
            rtmsg = strResultMsg("Error", TYPE, Resource_Id, new_vol)
            ch.log(rtmsg)
            sys.exit(1)
    except Exception, e:
        ch.log("%s" % e)
        ch.set_status_flag(TYPE, Resource_Id, "failed", ch.ERROR_MSG)
        rtmsg = strResultMsg("Error", TYPE, Resource_Id, new_vol)
        ch.log(rtmsg)
        sys.exit(1)

    sys.exit(0)


