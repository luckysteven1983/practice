#!/bin/sh

ACTIONTYPE=$1
OPTION=$2
if [ $ACTIONTYPE == "replacement" ]; then
       echo replace_${OPTION}
else
       echo ${ACTIONTYPE}
fi
	exit 0

