#!/bin/ksh

#this script is used to do two things:1.backup;2.query the backup status
#usage:./netbackup backupCmd
#the value of backupCmd can be one of below:
#	BACKUP:ALL	
#	BACKUP:SYSTEM
#	BACKUP:APPL
#	BACKUP:SITEDB=PLATDB
#	BACKUP:USER=XXX, XXX is created by another script:createUserBkupType,\ 
#	after configuration, the user info can also be got via /opt/config/data/usr_type_definition
#	if the backupCmd is not supplied, \this script will query the status of backup operation.\
#	the check file is the log file /opt/config/log/NetbpCmdLine.out

typeset BKLOGFILE=/opt/config/log/NetbpCmdLine.out
typeset LOGFILE=/tmp/netbackup.log
typeset BACKUPBINARY=/cs/sn/cr/cepexec
typeset BACKUPALLBINARY=BACKUP_ALL
typeset BACKUPSITEDBBINARY=BACKUP_SITEDB
typeset BACKUPPOLICYCONFIG=/opt/config/data/netbackup.policy
typeset USRTYPEDEFINATION=/opt/config/data/usr_type_definition
#define the size limitation is 10M
typeset FILESIZEMAX=10485760
typeset filezip=/tmp/netbackupLog.zip
typeset backAllCmd="BACKUP:ALL"
typeset backSystemCmd="BACKUP:SYSTEM"
typeset backSiteDbCmd="BACKUP:SITEDB"
typeset backApplCmd="BACKUP:APPL"
typeset backUserCmd="BACKUP:USER="
typeset errorMsg="The right usage should be \$cmd \$inputParam.\
			The inputParam can be BACKUP:ALL/BACKUP:SYSTEM/\
			BACKUP:APPL/BACKUP:SITEDB=PLATDB/BACKUP:USER=XXX/BACKUP:STATUS"

#this function is used to edit the response
function getBackupResponseInfo
{
	typeset backupMsg=""
	if [[ $# != 1 ]];
	then
		backupMsg='{"state":"failed","result":"ErrorCode['$1'], ErrorMsg['$2']"}'
	else
		backupMsg='{"state":"finished","result":"'$1'"}'
	fi
				
	log "$backupMsg"
	echo $backupMsg	
}

#this function is used to edit the response for query the status
function getStatusResponseInfo
{
	typeset statusMsg
	if [[ $# != 4 ]];
	then
		statusMsg='{"state":"'$1'","result":"BackupCmd['$2'],BackupPolicy['$3'],BackupBeginTime['$4'],Details['$5']"}'
	else
		statusMsg='{"state":"'$1'","result":"BackupCmd['$2'],BackupPolicy['$3'],BackupBeginTime['$4']"}'
	fi

	log "$statusMsg"
	echo $statusMsg
}

#this funciton is used to edit the response 
function getErrorMsg
{
	typeset errorMsg='{"state":"failed","result":"'$1'"}'

	log "$errorMsg"
	echo $errorMsg
}
		

#log information to logFiles
function log
{
	typeset logInfo=$1
	typeset filesize=0
	[[ -f $LOGFILE ]] && filesize=`ls -l $LOGFILE|awk '{print $5}'`

	if [[ $filesize -ge $FILESIZEMAX ]];
	then
        [[ -f $filezip ]] && rm -f $filezip;

        zip -qr $filezip $LOGFILE
		cat /dev/null > $LOGFILE
	fi

	echo "$logInfo" >> $LOGFILE
}

#this function is only used to check the result of backup, it assumpts that the netbackup is already finished.
#0 means successful, others means fail.
function getBackupResult
{
	typeset successFlag="NetbpCmdLine: NOTE: COMPLETE with [SUCCESS|WARNINGs|ALERTs]"
	(grep -qs "$successFlag" ${BKLOGFILE}) && result=1
	if [[ $result == 1 ]];
	then
		log "netbackup is executed successfully"
		echo 0
		return
	fi

	typeset failFlag1="NetbpCmdLine: ERROR: ABORTED due to [ERROR|SIGNAL|TIMEOUT]"
	typeset failFlag2="NetbpCmdLine: EXITING: ERROR:"
	typeset fail=0
	(grep  -qs "$failFlag1" ${BKLOGFILE}) && fail=1
	[[ $fail == 0 ]] && (grep  -qs "$failFlag2" ${BKLOGFILE}) && fail=1
	if [[ $fail == 1 ]];
	then
		typeset msg="netbackup is failed to be executed"
		echo 2
		return
	fi

	log "Current backup is still in progress"
	echo 3
}


#this function is used to get the error reason when fails
function getErrorReason
{
	typeset reason=`grep "NetbpCmdLine: ERROR:" ${BKLOGFILE} |grep bbpbackup`
	
	if [[ $reason == "" ]];
	then
		reason=`grep  "NetbpCmdLine: ERROR:" "${BKLOGFILE}"`
		log "reason is $reason"
	fi

	echo $reason
}


#this functions is used to check the progress of netbackup.
#1 means not begin; 3 means in progress ; 2 means finished; 0 means successful
function getBackupProgress
{
	typeset status="finished"
	typeset details=""
	typeset backupCmd="N/A"
	typeset res
	typeset policy="N/A"
	typeset time="N/A"
	
	if [[ !  -f ${BKLOGFILE} ]];
	then
		log "${BKLOGFILE} doesn't exist"
		res=1
	else
		res=`getBackupResult`
		policy=`grep "Preparing for netbackup as policy" $BKLOGFILE|awk -F " " '{printf("%s",$9)}'`
		time=`grep "Preparing for netbackup of" $BKLOGFILE|awk -F " " '{printf("%s",$3)}'`

		log "policy is $policy"

		if [[ $policy == "" ]]
		then
			typeset tmp=`grep "policy new setting update" $BKLOGFILE|awk -F " " '{printf("%s",$4)}'`
			[[ $tmp != "" ]] && policy=${tmp:1:${#tmp}-2}
			[[ $tmp == "" ]] && policy="N/A"
		fi

		[[ $policy != "N/A" ]] && backupCmd=`grep  "$policy" $BACKUPPOLICYCONFIG|awk -F " " '{printf("%s",$1)}'`
		[[ $time == "" ]] && time="N/A"
	fi
	
	log "res is $res, policy is $policy, backupCmd is $backupCmd"	

	case "$res" in
		0)
			details="The backup is compeleted successfully"
			;;

		1)	
			policy="N/A"
			details="The backup still doesn't begin"
			;;

		2)
			typeset reason=`getErrorReason`
			details="The backup is failed with error: $reason"
			;;

		3)	
			details="The backup is in progress"
			;;
	esac

	typeset resp=`getStatusResponseInfo "$status" "$backupCmd" "$policy" "$time" "$details"`
	echo $resp
	
}


#this function is used to do backup for command "BACKUP:ALL"
function backupAll
{
	typeset errorMsg="BACKUP:ALL is not configured yet"
	typeset keyWords="BACKUP:ALL"

	typeset config=0
    	grep -qs $keyWords $BACKUPPOLICYCONFIG && config=1

    	if [[ $config == 0 ]];
    	then
		log "Error: $errorMsg"
        	getErrorMsg "$errorMsg"
        	exit 1
    	fi

	$BACKUPBINARY $BACKUPALLBINARY $keyWords
}

#this function is used to do backup for command "BACKUP:SYSTEM"
function backupSystem
{
	typeset errorMsg="BACKUP:SYSTEM is not configured yet"
	typeset keyWords="BACKUP:SYSTEM"

	typeset config=0
	grep -qs $keyWords $BACKUPPOLICYCONFIG && config=1

	if [[ $config == 0 ]];
	then
		log "Error: $errorMsg"
		getErrorMsg "$errorMsg"
		exit 2
	fi

	$BACKUPBINARY $BACKUPALLBINARY $keyWords
}

#this function is used to do backup for command "BACKUP:APPL"
function backupAppl
{
	typeset keyWords="BACKUP:APPL"
	typeset errorMsg="BACKUP:APPL is not configured yet"

    	typeset config=0
    	grep -qs $keyWords $BACKUPPOLICYCONFIG && config=1

    	if [[ $config == 0 ]];
    	then
        	log "Error: $errorMsg"
        	getErrorMsg "$errorMsg"
        	exit 3
    	fi

	$BACKUPBINARY $BACKUPALLBINARY $keyWords
}

#this function is used to do backup for command "BACKUP:SITEDB"
function backupSiteDb
{
	typeset keyWords="BACKUP:SITEDB"
	typeset errorMsg="BACKUP:SITEDB is not configured yet"

    	typeset config=0
    	grep -qs $keyWords $BACKUPPOLICYCONFIG && config=1

    	if [[ $config == 0 ]];
    	then
        	log "Error: $errorMsg"
		getErrorMsg "$errorMsg"
		exit 4
    	fi

	$BACKUPBINARY $BACKUPSITEDBBINARY "BACKUP:SITEDB=PLATDB"
}

#this function is used to do backup for command "BACKUP:USER"
#in subshl, the command should be BACKUP:USER=XXX, XXX is the name of user.
#the usage of command is like " NetbpCmdLine -usrtype XXX
function backupUser
{
	typeset user=$1
	typeset keyWords="BACKUP:USER"

	$BACKUPBINARY $BACKUPALLBINARY "BACKUP:USER=$user"
}

#this function is used to check if the cmd can be run now, since there should only be 1 instance to run backup
function isReadyToBackup
{
	if [[ ! -f ${BKLOGFILE} ]];
	then
		log "${BKLOGFILE} doesn't exist"
		return
	fi
	
	typeset status=`getBackupResult`
	typeset errorMsg="There should only be 1 backup command running"
	log "status is $status"
	if [[ $status == 3 ]];
	then
		log "Error: $errorMsg"
		getBackupResponseInfo 3 "$errorMsg"	
		exit 5
	fi
}



if [ $# -ne 1 ];
then
	typeset msg="The input param number is wrong ,should be 1"
	log "Error: $msg"
	getErrorMsg "$msg"
	exit 6
fi
			
typeset cmd=$1		
log "input command is $cmd"

if [[ $cmd =~ $backAllCmd ]] 
then
	if [[ $cmd == $backAllCmd ]];
	then
		log "Begin to validate $cmd"
		isReadyToBackup $cmd
	
		log "Begin to run $cmd"
        	backupAll
	else
		log "Error: $cmd is not supported now"
		getErrorMsg "$cmd is not supported now"
		exit 7
	fi
elif [[ $cmd =~ $backSystemCmd ]]; 
then
	if [[ $cmd == $backSystemCmd ]];
	then
		log "Begin to validate $cmd"
		isReadyToBackup $cmd
	
		log "Begin to run $cmd"
		backupSystem
	else
		log "Error: $cmd is not supported now"
		getErrorMsg "$cmd is not supported now"
		exit 8
	fi
elif [[ $cmd =~ $backSiteDbCmd ]];
then
	typeset platDbBackupCmd="BACKUP:SITEDB=PLATDB"
	if [[ $cmd == $platDbBackupCmd ]];
	then
		log "Begin to validate $cmd"
		isReadyToBackup $cmd
 
		log "Begin to run $cmd"
	    	backupSiteDb
	else
		getErrorMsg "$cmd is not supported now"
		log "Error: $cmd is not supported now"
		exit 9
	fi	
elif [[ $cmd =~ $backApplCmd ]];
then
	if [[ $cmd == $backApplCmd ]];
	then
		log " Begin to validate $cmd"
		isReadyToBackup $cmd
         	
		log "Begin to run $cmd"
		backupAppl
	else
		getErrorMsg "$cmd is not supported now"
		log "Error: $cmd is not supported now"
		exit 10
	fi
elif [[ $cmd =~ $backUserCmd ]];
then
	log "Begin to validate $cmd"
	isReadyToBackup $cmd
  		
	log "Begin to run $cmd"
	typeset user=${cmd#*=}
	backupUser $user
	
elif [[ $cmd == "BACKUP:STATUS" ]];
then	
	typeset res=`getBackupProgress`
	log "current backup status is 	$res"
	
	echo $res
	exit 0
else
	log "Input[$cmd] is not supported now, exit with error"
	log "$errorMsg"

	getErrorMsg "$errorMsg"
	exit 11
fi

log "$cmd starts successfully"
getBackupResponseInfo "$cmd starts successfully, please use BACKUP:STATUS to query the status later"
exit 0
