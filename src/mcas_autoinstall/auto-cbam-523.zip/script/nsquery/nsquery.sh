#!/bin/ksh

#set -x

typeset LOGFILE=/tmp/nsquery.log
typeset FILESIZEMAX=10485760
typeset filezip=/tmp/nsquery.zip

typeset blankInput="null"

# this function is used to edit the response as json format
# retrun json format msg and exit with rtcode
function returnResponseInfo
{
    typeset rtcode=$1
    typeset respMsg=$2
    
    # remove invalid char for Json, including \", \, \b, \f, \n, \r, \t, '
    respMsg=$(echo $respMsg | sed 's/\"//g;s/\\//g;s/\\b//g;s/\\f//g;s/\\n//g;s/\\r//g;s/\\t//g' | sed "s/'//g")
    
    [ $# -ne 2 ] && { rtcode=99; respMsg="Error: Wrong input for returnResponseInfo."; }
    
    result="finished"
    [ $rtcode -ne 0 ] && result="failed"
    rtmsg='{"state":"'$result'","result":"'$respMsg'"}'
    
    log "$respMsg"
    echo $rtmsg
    
    exit $rtcode
}


#log information to logFiles
function log
{
    typeset logInfo=$1
    typeset filesize=0
    [[ -f $LOGFILE ]] && filesize=`ls -l $LOGFILE|awk '{print $5}'`

    if [[ $filesize -ge $FILESIZEMAX ]];
    then
        [[ -f $filezip ]] && rm -f $filezip

        zip -qr $filezip $LOGFILE
        cat /dev/null > $LOGFILE
    fi

    echo "$logInfo" >> $LOGFILE
}

#usage of current script
function Usage
{
    print -- "Usage: nsquery.sh <cmdtype> <cmdvalue> <cmdoption>"
    print -- "\t    Parameters: 
                            Parameter-1: cmdType
                            Parameter-2: cmdvalue
                            Parameter-3: cmdoption

            The valid values are showed as below:
            Type	Value       additoanlParams
            status 	vm		ALL|RCS|VNFC_ID|VM_NAME
            status 	spa		ALL|<Specific SPA Name>"
    exit $1
}

#for the mode nsquery
function nsquery
{
    # Must be executed on Active Pilot
    /opt/config/lib/pilot_is_active || { print "This operation must be executed on Active Pilot."; return 1; }
    
    case "$cmdvalue" in
        vm)
            cmd="OP:STATUS, MACHINE=$cmdoption"
            subshl_exec "$cmd"
            return $?
        ;;
        spa)
            cmd="OP:STATUS, SPA=$cmdoption"
            subshl_exec "$cmd"
            return $?
        ;;
        *)
            print "The Command Value[$cmdvalue] is not valid under Command Type[$cmdtype]"
            return 1
        ;;
        esac

    return 0
}

# subshl commands
function subshl_exec
{
    cmd="$1"
    [ -z "$cmd" ] && { echo "Command input cannot be empty."; return 1; }
    
    [ -f /sn/cr/textsh ] || { echo "Not found /sn/cr/textsh."; return 1; }
     
    echo "$cmd" | /sn/cr/textsh -F 2>&1
    return $?
    
}

# Begin Main methods
[ "$1" == "-h" ] && Usage 0

typeset cmd
typeset rc=0
typeset rtmsg

[ "$#" -ne 3 ] && {
    rtmsg="3 parameters are needed."
    rc=1
    returnResponseInfo $rc "$rtmsg"
}

typeset -l cmdtype=$1
typeset -l cmdvalue=$2
typeset cmdoption=$3

# If input is 'null', consider as empty input
[ "x$cmdtype" == "x$blankInput" ] && cmdtype=""
[ "x$cmdvalue" == "x$blankInput" ] && cmdvalue=""
[ "x$cmdoption" == "x$blankInput" ] && cmdoption=""
[ -z "$cmdtype" ] && {
    rtmsg="The CommandType cannot be empty."
    rc=1
    returnResponseInfo $rc "$rtmsg"
}

[ -z "$cmdvalue" ] && {
    rtmsg="The CommandValue cannot be empty."
    rc=1
    returnResponseInfo $rc "$rtmsg"
}

[ -z "$cmdoption" ] && cmdoption="ALL"

case "$cmdtype" in
    status)
        cmd="nsquery"
    ;;
    *)
        rtmsg="The Command[$cmdtype] is not suppported , please ref the usage"
        rc=1
        returnResponseInfo $rc "$rtmsg"
        #Usage 1
    ;;
esac

# Execute SU steps and return json format messages
[ -n "$cmd" ] && { rtmsg=$($cmd); rc=$?; }

returnResponseInfo $rc "$rtmsg"

exit 0

