#!/bin/ksh

#this script is used to do a conversion from efix script to json format output.
#normally, the efix script will return an integar value, 0 means success,others fail.


typeset LOGFILE=/tmp/efix.log
typeset FILESIZEMAX=10485760
typeset filezip=/tmp/efix.zip
typeset efixName

function Usage
{
    print  "Usage: efix.sh <operation> "
    print  "\t    Operation: Check, Apply, Commit, Cleanup, Backout "
    exit $1

}
function returnResponseInfo
{
    typeset rtcode=$1
    typeset respMsg=$2
    typeset logMsg="$respMsg"

    # remove invalid char for Json, including \", \, \b, \f, \n, \r, \t, '
    respMsg=$(echo $respMsg | sed 's/\"//g;s/\\//g;s/\\b//g;s/\\f//g;s/\\n//g;s/\\r//g;s/\\t//g' | sed "s/'//g")

    # comment below 2 lines in official code
    typeset debugMsg="Input parameters: operation=[$operation]."
    respMsg="${debugMsg} $respMsg"

    [ $# -ne 2 ] && { rtcode=99; respMsg="Error: Wrong input for returnResponseInfo."; }

    result="finished"
    [ $rtcode -ne 0 ] && result="failed"
    rtmsg='{"state":"'$result'","result":"'$respMsg'"}'

    log "$logMsg"
    echo $rtmsg

    exit $rtcode
}

function log
{
    typeset logInfo=$1
    typeset filesize=0
    [[ -f $LOGFILE ]] && filesize=`ls -l $LOGFILE|awk '{print $5}'`

    if [[ $filesize -ge $FILESIZEMAX ]];
    then
        [[ -f $filezip ]] && rm -f $filezip

        zip -qr $filezip $LOGFILE
        cat /dev/null > $LOGFILE
    fi

    echo "$logInfo" >> $LOGFILE
}
function check
{
    # Must be executed on Active Pilot
    /opt/config/lib/pilot_is_active || { print "This operation must be executed on Active Pilot."; return 1; }

    fileNum=`find /etc/SU/ -name "ltefx*.tar.gz" -type f | wc -l || echo 0`
    [ $fileNum -eq 0 ] && { print "No efix package on /etc/SU"; return 1; }
    [ $fileNum -gt 1 ] && { print "Found multi efix packages on /etc/SU"; return 1;}

    efixName=$(getEfixName)

    [ -f /etc/SU/$efixName.md5sum ] || { print "Not found $efixName.md5sum on /etc/SU."; return 1; }
    md5Value=`/bin/cat /etc/SU/$efixName.md5sum | /bin/awk {'print $1'} | /bin/tr -d '\n'`
    checkMd5Value=`/bin/md5sum /etc/SU/$efixName.tar.gz | /bin/awk {'print $1'} | /bin/tr -d '\n'`
    [ -n "$checkMd5Value" ] || { print "Get md5 value of $efixName.tar.gz failed."; return 1;} 
    [ "x$md5Value" ==  "x$checkMd5Value" ] || { print "Check md5 value failed , not same with $efixName.md5sum."; return 1; }

    direcNum=`find /etc/SU/ -name "$efixName" -type d | wc -l || echo 0`
    [ $direcNum -eq 0 ] && { tar zxfvo /etc/SU/"$efixName".tar.gz -C /etc/SU/; }
    [ $direcNum -gt 1 ] && { print "Found multi efix directory on /etc/SU"; return 1;}
    fileList="EFXinstall EFXcheck EFXapply EFXbackout EFXcommit"
    for i in `echo $fileList` 
    do
        checkFile=`/bin/find /etc/SU/$efixName/bin/ -name $i -type f | wc -l || echo 0`
        [ $checkFile -eq 0 ] && { print "No $i found on /etc/SU/$efixName/bin/" ; return 1; }
    done
    efixOperation CHECK
    return $?

}
function getEfixName
{
    typeset efixName
    efixName=`basename /etc/SU/ltefx*.tar.gz | sed 's/\.tar\.gz//'`
    echo ${efixName}
    return 0
}
function efixOperation
{
    efixName=$(getEfixName)
    /etc/SU/$efixName/bin/EFXinstall $1 2>&1
    return $?
}
function cleanUp
{
    efixName=$(getEfixName)
    lastOperation=`/bin/cat /etc/SU/$efixName/data/State| tr -d '\n'`
    if [ "x$lastOperation" == "xEFXcommit_COMMIT:Compl" -o "x$lastOperation" == "xEFXbackout_BACKOUT:Compl" ]; then
        /bin/rm -rf  /etc/SU/ltefx* || { print "Clean up failed to delete efix directory on /etc/SU" ; return 1; }
    else 
        print "Last operation is $lastOperation, can not excute cleanUp"
        return 1
    fi
    return 0
}



[ "$1" == "-h" ] && Usage 0
typeset cmd
typeset rc=0
typeset rtmsg

[ "$#" -ne 1 ] && {
    rtmsg="One parameters are needed."
    rc=1
    returnResponseInfo $rc "$rtmsg"
}


typeset -l operation=$1

case "$operation" in
    check)
        cmd="check"
    ;;
    apply)
        cmd="efixOperation APPLY"
    ;;
    commit)
        cmd="efixOperation COMMIT"
    ;;
    backout)
        cmd="efixOperation BACKOUT"
    ;;
    cleanup)
        cmd="cleanUp"
    ;;
    *)
        rtmsg="The operation $operation is not suppported."
        rc=1
        returnResponseInfo $rc "$rtmsg"
        #Usage 1
    ;;
esac
# Execute SU steps and return json format messages
[ -n "$cmd" ] && { rtmsg=$($cmd); rc=$?; }
returnResponseInfo $rc "$rtmsg"

exit 0

