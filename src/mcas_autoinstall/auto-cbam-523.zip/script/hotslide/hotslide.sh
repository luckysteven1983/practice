#!/bin/ksh

#this script is used to do a conversion from hotslide script to json format output.
#normally, the hotslide script will return an integar value, 0 means success,others fail.


typeset LOGFILE=/tmp/hotslide.log
typeset FILESIZEMAX=10485760
typeset filezip=/tmp/hotslide.zip
typeset blankInput="null"

function Usage
{
    print  -- "Usage: hotslide.sh <mode> <operation> <option> <spaName>"
    print  -- "\t   Parameters:
                            Parameter-1: mode
                            Parameter-2: operation
                            Parameter-3: option
                            Parameter-4: spaName

            The valid values are showed as below:
            mode        operation       additoanlParams
            Apply       Apply           spaName
                        Commit          spaName
            Backout     Apply           spaName
            Query       Query           Active
                        Query           All
                        Query           Backout
                        Query           Committed"

    exit $1

}
function returnResponseInfo
{
    typeset rtcode=$1
    typeset respMsg=$2
    typeset logMsg="$respMsg"

    # remove invalid char for Json, including \", \, \b, \f, \n, \r, \t, '
    respMsg=$(echo $respMsg | sed 's/\"//g;s/\\//g;s/\\b//g;s/\\f//g;s/\\n//g;s/\\r//g;s/\\t//g' | sed "s/'//g")

    # comment below 2 lines in official code
    typeset debugMsg="Input parameters: operation=[$operation]."
    respMsg="${debugMsg} $respMsg"

    [ $# -ne 2 ] && { rtcode=99; respMsg="Error: Wrong input for returnResponseInfo."; }

    result="finished"
    [ $rtcode -ne 0 ] && result="failed"
    rtmsg='{"state":"'$result'","result":"'$respMsg'"}'

    log "$logMsg"
    echo $rtmsg

    exit $rtcode
}

function log
{
    typeset logInfo=$1
    typeset filesize=0
    [[ -f $LOGFILE ]] && filesize=`ls -l $LOGFILE|awk '{print $5}'`

    if [[ $filesize -ge $FILESIZEMAX ]];
    then
        [[ -f $filezip ]] && rm -f $filezip

        zip -qr $filezip $LOGFILE
        cat /dev/null > $LOGFILE
    fi

    echo "$logInfo" >> $LOGFILE
}
# subshl commands
function subshl_exec
{
    cmd="$1"
    [ -z "$cmd" ] && { echo "Command input cannot be empty."; return 1; }

    [ -f /sn/cr/textsh ] || { echo "Not found /sn/cr/textsh."; return 1; }

    echo "$cmd" | /sn/cr/textsh -F 2>&1
    return $?

}

function apply
{
    # Must be executed on Active Pilot
    /opt/config/lib/pilot_is_active || { print "This operation must be executed on Active Pilot."; return 1; }
    [ -z "$spaName" ] && { print "The operation[$operation] and  mode[$mode] need  parameter spaName." ; return 1 ;}
    case "$operation" in
        apply)
            [ -f /etc/SU/"$spaName".full.tar ] || [ -f /etc/SU/"$spaName".hotslide.tar ] || { print "Not found $spaName.full.tar or $spaName.hotslide.tar on /etc/SU." ; return 1 ;}
            /bin/touch /etc/SU/.READY_TO_INSTALL_$spaName || { print "Touch .READY_TO_INSTALL_$spaName failed on /etc/SU." ; return 1; }
            subshl_exec "upd:apply, hotslide, spa=$spaName"
            return $?
        ;;
        commit)
            output=`expect -c "
            set timeout 300
            spawn /cs/sn/cep/subshl
            expect \"<\"
            send \"UPD:COMMIT,HOTSLIDE,SPA=$spaName;\"
            expect \"N?\"
            send \"Y\n\"
            expect \"END OF REPORT\"
            send \"quit\n\"
            " 2>&1`
            echo $output | sed 's/\\r//g;s/\r//g;'
            return 0
        ;;
        *)
            print "The operation[$operation] is not valid under mode[$mode]"
            return 1
        ;;
        esac
    return 0
}

function backout
{
    # Must be executed on Active Pilot
    /opt/config/lib/pilot_is_active || { print "This operation must be executed on Active Pilot."; return 1; }
    [ -z "$spaName" ] && { print "The operation[$operation] and  mode[$mode] need  parameter spaName." ; return 1 ;}
    case "$operation" in
        apply)
            subshl_exec "upd:bkout, hotslide, spa=$spaName"
            return $?
        ;;
        *)
            print "The operation[$operation] is not valid under mode[$mode]"
            return 1
        ;;
        esac
    return 0
}

function query
{
    [ -z "$option" ] && { print "The operation[$operation] and  mode[$mode] need  parameter option." ; return 1;}
    case "$operation" in
        query)
            case "$option" in 
                active)
                    cmd="ACTIVE"
                ;;
                all)
                    cmd="ALL"
                ;;

                backout)
                    cmd="BACKEDOUT"
                ;;

                committed)
                    cmd="COMMITTED"
                ;;
                *)
                    print "The additionalPara[$additionalPara] is not valid under mode[$mode]"
                    return 1
                ;;
            esac
            subshl_exec "upd:print,spa,$cmd"
            return $?
        ;;
        *)
            print "The operation[$operation] is not valid under mode[$mode]"
            return 1
        ;;
    esac
    return 0
}   
           



# Begin Main methods
[ "$1" == "-h" ] && Usage 0
typeset cmd
typeset rc=0
typeset rtmsg

[ "$#" -ne 4 ] && {
    rtmsg="Four parameters are needed."
    rc=1
    returnResponseInfo $rc "$rtmsg"
}


typeset -l mode=$1
typeset -l operation=$2
typeset -l option=$3
typeset spaName=$4

[ "x$mode" == "x$blankInput" ] && mode=""
[ "x$operation" == "x$blankInput" ] && operation=""
[ "x$option" == "x$blankInput" ] && option=""
[ "x$spaName" == "x$blankInput" ] && spaName=""

[ -z "$mode" ] && {
    rtmsg="The mode cannot be empty or null."
    rc=1
    returnResponseInfo $rc "$rtmsg"
}

[ -z "$operation" ] && {
    rtmsg="The operation cannot be empty or null."
    rc=1
    returnResponseInfo $rc "$rtmsg"
}



case "$mode" in
    apply)
        cmd="apply"
    ;;
    backout)
        cmd="backout"
    ;;
    query)
        cmd="query"
    ;;
    *)
        rtmsg="The operation $operation is not suppported."
        rc=1
        returnResponseInfo $rc "$rtmsg"
        #Usage 1
    ;;
esac
# Execute SU steps and return json format messages
[ -n "$cmd" ] && { rtmsg=$($cmd); rc=$?; }
returnResponseInfo $rc "$rtmsg"

exit 0

