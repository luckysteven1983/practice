#!/bin/ksh

#set -x

typeset MISTRAL_DB_MANAGE="/opt/nokia/mistral/venv/bin/mistral-db-manage"
typeset MISTRAL_CONF="/opt/nokia/mistral/etc/mistral/mistral.conf"
typeset MAPPING_JSON="/opt/nokia/mistral/venv/lib/python2.7/site-packages/cbam_workflows/actions/openstack/mapping.json"
typeset NEW_ACTIONS="nova:servers_create_image:servers.create_image nova:images_findall:images.findall glance:images_create:images.create glance:images_list:images.list"
typeset needAdd=1

[ $(/bin/whoami) != 'root' ] && { echo "Please use 'root' account to re-run."; exit 1; }

[ -f ${MISTRAL_DB_MANAGE} ] || { echo "Not found ${MISTRAL_DB_MANAGE}."; exit 1; }
[ -f ${MISTRAL_CONF} ] || { echo "Not found ${MISTRAL_CONF}."; exit 1; }
[ -f ${MAPPING_JSON} ] || { echo "Not found ${MAPPING_JSON}."; exit 1; }

function add_action
{
    [ -z "$1" ] && { echo "No action input."; exit 1; }
    echo $1 | awk -F':' '{$1=$1; print}' | read module actionName actionCmd

    [ -z "$module" ] && { echo "Module is empty."; exit 1; }
    [ -z "$actionName" ] && { echo "actionName is empty."; exit 1; }
    [ -z "$actionCmd" ] && { echo "actionCmd is empty."; exit 1; }

    firstOrNot=`cat ${MAPPING_JSON} | grep "\"${module}\": {}" `
    if [ $? -ne 0 ];then
    actionStr="\t\"${actionName}\": \"${actionCmd}\","
    else
    actionStr="\t\"${actionName}\": \"${actionCmd}\""
    fi
    cat /opt/nokia/mistral/venv/lib/python2.7/site-packages/cbam_workflows/actions/openstack/mapping.json | python -c 'import json; import sys; print(json.load(sys.stdin)["'$module'"])' > /dev/null 2>&1 || { echo "Not found any ${module} action in ${MAPPING_JSON}."; exit 1; }
    cat /opt/nokia/mistral/venv/lib/python2.7/site-packages/cbam_workflows/actions/openstack/mapping.json | python -c 'import json; import sys; print(json.load(sys.stdin)["'$module'"]["'$actionName'"])' > /dev/null 2>&1 && { echo "Action ${actionName} already exist."; return 0; }

    /bin/sed -i "s/\"${module}\": {/\"${module}\": {\\n${actionStr}/" ${MAPPING_JSON}
    [ $? -ne 0 ] && { echo "Failed to update ${MAPPING_JSON}."; exit 1; }
    needAdd=0
}

for action in ${NEW_ACTIONS}
do
    add_action $action
done

[ $needAdd -eq 1 ] && { echo "All actions to be added already exist."; exit 0; }

${MISTRAL_DB_MANAGE} --config-file ${MISTRAL_CONF} populate
[ $? -ne 0 ] && { echo "Failed to populate new actions."; exit 1; }

echo "Successfully add new actions."
exit 0

