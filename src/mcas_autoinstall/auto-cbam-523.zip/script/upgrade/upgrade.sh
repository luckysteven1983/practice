#!/bin/ksh

#this script is used to do a conversion from SU script to json format output.
#normally, the SU script will return an integar value, 0 means success,others fail.
#this script will be used to convert the original output to a json format, so that 
#the output can be showed in the cbam.

#set -x

typeset LOGFILE=/tmp/su.log
typeset FILESIZEMAX=10485760
typeset filezip=/tmp/su.zip

typeset blankInput="null"

# this function is used to edit the response as json format
# retrun json format msg and exit with rtcode
function returnResponseInfo
{
    typeset rtcode=$1
    typeset respMsg=$2
    typeset logMsg="$respMsg"
    
    # remove invalid char for Json, including \", \, \b, \f, \n, \r, \t, ', the 1st 'Term type is now xterm ' & 'No mail for root '
    respMsg=$(echo $respMsg | sed 's/\"//g;s/\\//g;s/\\b//g;s/\\f//g;s/\\n//g;s/\\r//g;s/\\t//g;s/Term type is now xterm //;s/No mail for root //' | sed "s/'//g")
    
    # comment below 2 lines in official code
    typeset debugMsg="Input parameters: mode=[$mode], operation=[$operation], URI=[$URI], Force=[$Force], NodeList=[$NodeList], ImageList=[$ImageList], option=[$option]."
    respMsg="${debugMsg} $respMsg"  
    
    [ $# -ne 2 ] && { rtcode=99; respMsg="Error: Wrong input for returnResponseInfo."; }
    
    result="finished"
    [ $rtcode -ne 0 ] && result="failed"
    rtmsg='{"state":"'$result'","result":"'$respMsg'"}'
    
    log "$logMsg"
    echo $rtmsg
    
    exit $rtcode
}


#log information to logFiles
function log
{
    typeset logInfo=$1
    typeset filesize=0
    [[ -f $LOGFILE ]] && filesize=`ls -l $LOGFILE|awk '{print $5}'`

    if [[ $filesize -ge $FILESIZEMAX ]];
    then
        [[ -f $filezip ]] && rm -f $filezip

        zip -qr $filezip $LOGFILE
        cat /dev/null > $LOGFILE
    fi

    echo "$logInfo" >> $LOGFILE
}

#usage of current script
function Usage
{
    print -- "Usage: upgrade.sh <mode> <operation> <URI> <Force> <NodeList> <ImageList> <option>"
    print -- "\t    Parameters: 
                            Parameter-1: mode
                            Parameter-2: operation
                            Parameter-3: URI
                            Parameter-4: Force
                            Parameter-5: NodeList
                            Parameter-6: ImageList
                            Parameter-7: option

            The valid values are showed as below:
            mode        operation       additoanlParams
            Prepare     PrepareCheck
                        PrepareSU       URI, Force
            Upgrade     DrainLoad       NodeList
                        Snapshot        NodeList,ImageList
                        Rebuild         NodeList,ImageList
                        Apply
                        Finish
            Backout     Lastpilotrecover  checkDRBD
                        Prepare         NodeList,ImageList
                        Rebuild         NodeList,ImageList
                        Apply
                        Finish
            Query       UpgradeStatus
                        Version"         
    exit $1
}

#for the mode is prepare
function prepare
{
    # Must be executed on Active Pilot
    /opt/config/lib/pilot_is_active || { print "This operation must be executed on Active Pilot."; return 1; }
    
    case "$operation" in
        preparecheck)
            [ -f /repsysdata/OAM/IMG/bin/PREPARE ] || { print "Not found /repsysdata/OAM/IMG/bin/PREPARE."; return 1; }
            su - root -c "/repsysdata/OAM/IMG/bin/PREPARE -P" 2>&1
            return $?
        ;;
        preparesu)
            [ -f /opt/config/bin/PrepareSU ] || { print "Not found /opt/config/bin/PrepareSU."; return 1; }

            [ -z "$URI" ] && { print "URI cannot be empty."; return 1; }

            typeset forceFlag=""
            if [ "x$Force" != "xnull" ]; then
                [ -n "$Force" -a "x$Force" != "xtrue" -a  "x$Force" != "xfalse" ] && { print "Force flag must be set to True or False."; return 1; }
                [ "x$Force" = "xtrue" ] && forceFlag="-F"
            fi

            su - root -c "/opt/config/bin/PrepareSU $forceFlag $URI" 2>&1
            return $?
        ;;
        *)
            print "The operation[$operation] is not valid under mode[$mode]"
            return 1
        ;;
    esac
        
    return 0
}

#for the mode is upgrade
function upgrade
{
    # Must be executed on Active Pilot
    /opt/config/lib/pilot_is_active || { print "This operation must be executed on Active Pilot."; return 1; }
    
    case "$operation" in
        drainload)
            #validate the nodeList if it is valid
            [ -z "$NodeList" ] && { print "NodeList must be input."; return 1; }
            # convert NodeList to RCS which will be used to do DrainLoad
            # rcsList split multiple rcs with ':'
            rcsList=$(convertNodelist "$NodeList")
            [ -z "$rcsList" ] && { print "Failed to get valid rcs list"; return 1; }
            
            # Execute DrainLoad with $rcsList as input
            su - root -c "/repsysdata/OAM/IMG/bin/DRAIN_LOAD $rcsList" 2>&1
            return $?
        ;;
        snapshot)
            print "Ansbile script doesn't support SnapShot function."; 
            return 1;
        ;;
        rebuild)
            print "Ansbile script doesn't support Rebuild function."; 
            return 1;
        ;;
        apply)
            [ -f /repsysdata/OAM/IMG/bin/UPGRADE ] || { print "Not found /repsysdata/OAM/IMG/bin/UPGRADE."; return 1; }
            su - root -c "/repsysdata/OAM/IMG/bin/UPGRADE" 2>&1
            return $?
        ;;
        finish)
            [ -f /repsysdata/OAM/IMG/bin/FINISH ] || { print "Not found /repsysdata/OAM/IMG/bin/FINISH."; return 1; }
            su - root -c "/repsysdata/OAM/IMG/bin/FINISH" 2>&1
            return $?
        ;;
        *)
            print "The operation[$operation] is not valid under mode[$mode]"
            return 1
        ;;
    esac

    return 0
}

#for the mode is backout
function backout
{
    /opt/config/lib/pilot_is_active || { print "This operation must be executed on Active Pilot."; return 1; }
    
    case "$operation" in
        lastpilotrecover)
            typeset -l checkDRBD=$option
            [ -n "${checkDRBD}" -a "x${checkDRBD}" != "xcheckdrbd" ] && { print "Option must be set to checkDRBD or not set."; return 1; }
            
            typeset standbyPilotRCS
            standbyPilotRCS=$(getStandbyPilotRCS) || return $?
            
            if [ "x$checkDRBD" == "xcheckdrbd" ]; then
                /bin/ssh -q ${standbyPilotRCS} "/sbin/drbd-overview" 2>&1
                return $?
            else
                /sn/ft/FTrmvNode -O -u ${standbyPilotRCS} 2>&1
                rc=$?
                [ $rc -ne 0 ] && return $rc

                typeset -a cmdArray=("/etc/Astop local ucl" "/bin/rm -f /root/SETUPDISKS.*" "/bin/rm -f /root/restore_files_forSU" "/bin/touch /root/SETUPDISKS.create_drbds" "/bin/sync;/bin/sync" "/sbin/reboot")
                for ((i=0;i<${#cmdArray[@]};i++))
                do
                    remoteCmd=${cmdArray[$i]}
                    echo "Executing ${remoteCmd} on standby pilot."
                    /bin/ssh -q ${standbyPilotRCS} "${remoteCmd}" 2>&1
                    rc=$?
                    [ $rc -ne 0 ] && return $rc
                done
            fi
            return 0
        ;;
        prepare)
            [ -f /repsysdata/OAM/IMG/bin/BACKOUT_PREPARE ] || { print "Not found /repsysdata/OAM/IMG/bin/BACKOUT_PREPARE."; return 1; }
            su - root -c "/repsysdata/OAM/IMG/bin/BACKOUT_PREPARE" 2>&1
            return $?
        ;;
        drainload)
            #validate the nodeList if it is valid
            [ -z "$NodeList" ] && { print "NodeList must be input."; return 1; }
            # convert NodeList to RCS which will be used to do DrainLoad
            # rcsList split multiple rcs with ':'
            rcsList=$(convertNodelist "$NodeList")
            [ -z "$rcsList" ] && { print "Failed to get valid rcs list"; return 1; }
            
            # Execute DrainLoad with $rcsList as input
            su - root -c "/repsysdata/OAM/IMG/bin/DRAIN_LOAD $rcsList" 2>&1
            return $?
        ;;
        rebuild)
            print "Ansbile script doesn't support Rebuild function."; 
            return 1;
            ;;
        apply)
            [ -f /repsysdata/OAM/IMG/bin/UPGRADE ] || { print "Not found /repsysdata/OAM/IMG/bin/UPGRADE."; return 1; }
            su - root -c "/repsysdata/OAM/IMG/bin/UPGRADE" 2>&1
            return $?
        ;;
        finish)
            [ -f /repsysdata/OAM/IMG/bin/BACKOUT_FINISH ] || { print "Not found /repsysdata/OAM/IMG/bin/BACKOUT_FINISH."; return 1; }
            su - root -c "/repsysdata/OAM/IMG/bin/BACKOUT_FINISH" 2>&1
            return $? 
        ;;
        *)
            print "The operation[$operation] is not valid under mode[$mode]"
            return 1
        ;;
    esac
    
    return 0
}


#for the mode query
function query
{
    # Must be executed on Active Pilot
    /opt/config/lib/pilot_is_active || { print "This operation must be executed on Active Pilot."; return 1; }
    
    case "$operation" in
        upgradestatus)
            [ -z "$option" ] && { print "Query option must be input."; return 1; }
            typeset -l statusopt=$option
            # do not support multiple query inputs 
            case "$statusopt" in
                fullstatus)
                    /repsysdata/OAM/IMG/bin/STATUS -F 2>&1
                    return $?
                ;;
                history)
                    /repsysdata/OAM/IMG/bin/STATUS -H 2>&1
                    return $?
                ;;
                systemstatus)
                    /repsysdata/OAM/IMG/bin/STATUS -S 2>&1
                    return $?
                ;;
                fullandsystemstatus | allstatus)
                    /repsysdata/OAM/IMG/bin/STATUS -A 2>&1
                    return $?
                ;;
                *)
                    print "Invalid option input: $option."
                    return 1
                ;;
            esac
        ;;
        version)
            typeset -l versionopt=$option
            case "$versionopt" in
                "")
                    cmd="OP:VERSION"
                ;;
                history)
                    cmd="OP:VERSION,HISTORY"
                ;;
                all)
                    cmd="OP:VERSION,ALL"
                ;;
                *)
                    print "Invalid option input: $option."
                    return 1
                ;;
            esac 
            subshl_exec "$cmd"
            return $?
        ;;
        *)
            print "The operation[$operation] is not valid under mode[$mode]"
            return 1
        ;;
        esac

    return 0
}

# subshl commands
function subshl_exec
{
    cmd="$1"
    [ -z "$cmd" ] && { echo "Command input cannot be empty."; return 1; }
    
    [ -f /sn/cr/textsh ] || { echo "Not found /sn/cr/textsh."; return 1; }
     
    echo "$cmd" | /sn/cr/textsh -F 2>&1
    return $?
    
}

# Validate and convert the nodeList to rcslist
function convertNodelist
{
    typeset vmlist=$1
    typeset rcslist=""
    
    clientMap=/opt/config/conf/vm/client.map
    [ -f $clientMap ] || { echo "Not found $clientMap."; return 1; }
    
    for vmId in `echo $vmlist | awk -F':' '{$1=$1; print}'`
    do
        rcs=`grep -w $vmId /opt/config/conf/vm/client.map | awk '{print $1}'`
        [ -z $rcs ] && { echo "Failed to get valid rcs for $vmId."; return 1; }
        
        [ -z "$rcslist" ] && { rcslist=$rcs; continue; }
        rcslist="$rcslist:$rcs"
    done
    
    echo $rcslist
    return 0
}

# Get standby pilot RCS
function getStandbyPilotRCS
{
    typeset pilotA
    typeset pilotB
    typeset myRCS
    typeset standbyRCS
    
    /opt/config/lib/get_pilot_RCS | read pilotA pilotB
    [ -z "$pilotA" ] && { echo "Failed to get pilot rcs."; return 1; }
    [ -z "$pilotB" ] && { echo "This is single pilot server. Not need to perform last pilot recover."; return 1; }

    /opt/config/lib/get_my_rcs | read myRCS x
    [ -z "$myRCS" ] && { echo "Failed to get my rcs."; return 1; }
    
    if [[ "$myRCS" == "$pilotA" ]]; then
        standbyRCS="$pilotB"
    elif [[ "$myRCS" == "$pilotB" ]]; then
        standbyRCS="$pilotA"
    else
        echo "Failed to get standby pilot rcs."
        return 1
    fi

    echo ${standbyRCS}
    return 0
}

# Begin Main methods
[ "$1" == "-h" ] && Usage 0

typeset cmd
typeset rc=0
typeset rtmsg

[ "$#" -ne 7 ] && {
    rtmsg="7 parameters are needed."
    rc=1
    returnResponseInfo $rc "$rtmsg"
}

# for mode ,operation and Force, ignore case sensitive
# for other parameters, keep users' input
typeset -l mode=$1
typeset -l operation=$2
typeset URI=$3
typeset -l Force=$4
typeset NodeList=$5
typeset ImageList=$6
typeset option=$7

# If input is 'null', consider as empty input
[ "x$mode" == "x$blankInput" ] && mode=""
[ "x$operation" == "x$blankInput" ] && operation=""
[ "x$URI" == "x$blankInput" ] && URI=""
[ "x$Force" == "x$blankInput" ] && Force=""
[ "x$NodeList" == "x$blankInput" ] && NodeList=""
[ "x$ImageList" == "x$blankInput" ] && ImageList=""
[ "x$option" == "x$blankInput" ] && option=""

[ -z "$mode" ] && {
    rtmsg="The mode cannot be empty or null."
    rc=1
    returnResponseInfo $rc "$rtmsg"
}

[ -z "$operation" ] && {
    rtmsg="The operation cannot be empty or null."
    rc=1
    returnResponseInfo $rc "$rtmsg"
}

case "$mode" in
    prepare)
        cmd="prepare"
    ;;
    upgrade)
        cmd="upgrade"
    ;;
    backout)
        cmd="backout"
    ;;
    query)
        cmd="query"
    ;;
    *)
        rtmsg="The mode[$mode] is not suppported."
        rc=1
        returnResponseInfo $rc "$rtmsg"
        #Usage 1
    ;;
esac

# Execute SU steps and return json format messages
[ -n "$cmd" ] && { rtmsg=$($cmd); rc=$?; }
returnResponseInfo $rc "$rtmsg"

exit 0

