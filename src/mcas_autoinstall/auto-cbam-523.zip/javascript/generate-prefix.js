return {
    cbam: $.stack_params.cbam,
    server_name_prefix: $.vnf_attributes.vnfInstanceName
}
