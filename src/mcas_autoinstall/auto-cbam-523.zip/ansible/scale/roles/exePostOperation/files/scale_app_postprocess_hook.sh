# Application need add their sevices logic here itself
echo "----- scale_app_postprocess_hook.sh ======== have been called!!!==" >> /tmp/scale/scale_app_post_hook.log