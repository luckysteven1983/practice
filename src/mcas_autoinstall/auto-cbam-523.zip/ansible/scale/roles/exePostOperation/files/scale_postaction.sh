#!/bin/sh

typeset tmpPath="/tmp/scale"
typeset appFile="/tmp/scale/scale_app_postprocess_hook.sh"
typeset logFile="/tmp/scale_postaction_log"
typeset prepareDegrowFile="/tmp/scale/prepareDegrowFile"
typeset scaleOutPostFile="/tmp/scale/vmIdFile_scale_new.txt"
typeset BACKUPBINARY="/cs/sn/cr/cepexec"
typeset BACKUPALLBINARY="BACKUP_ALL"
typeset DegrowNodeCmd="BACKUP:DEGROW="
typeset confFile="/tmp/scale/export.sh"
typeset exportCmd="export BOOTMGR=yes"

#mcasid-11
typeset degrowActionFile="/tmp/scale/degrow"
typeset scaleInfoFile="/tmp/scale/scaleInfo"
typeset degrowSingleGroupFile="/tmp/scale/single"
typeset countFile="/opt/config/conf/servers_count"

if [ -f "$logFile" ]; then
    rm -rf $logFile
    touch $logFile
fi

log(){
    echo $1 >> $logFile
}

#mcasid-11
typeset nodeCount=0
log "BEGIN SCALE POST ACTION!"
if [ -d "$tmpPath" ]; then
    if [ -f "$scaleOutPostFile" ]; then
        if [ -f "$appFile" ]; then
            log "run before scale_app_postprocess_hook.sh"
            `/bin/sh $appFile &`
            log "call scale_app_postprocess_hook.sh SUCCESS"
        else
                    log "no scale_app_postprocess_hook.sh need run"
        fi
        log "Post Action For Scale Out DONE"
    else
        if [ ! -f "$prepareDegrowFile" ]; then
            log "FAI: File: $prepareDegrowFile not exist"
            exit 1
        fi

        log "Read file: $prepareDegrowFile, do DegrowNodes for each node in it"
        if [ -f "$confFile" ]; then
                        rm -rf $confFile
                        touch $confFile
        fi
        echo $exportCmd >> $confFile
        log "EXPORT BOOTMGR=yes"
        source $confFile
        VHOSTPATTERN="vhost_[0-9]+"
        
	#mcasid-11
	nodeCount=`cat $prepareDegrowFile|wc -l`
        if [ -f $degrowActionFile ]; then
			if [ ! -f $degrowSingleGroupFile ]; then
                nodeCount=`expr $nodeCount + $nodeCount`
            fi
        fi
        log "nodeCount is $nodeCount"
	
        cat $prepareDegrowFile | awk -F '=' '{print $2}' | while read degrowNode
        do
                                    if [[ $degrowNode =~ $VHOSTPATTERN ]]; then
                                        vhostId=`echo $degrowNode | awk -F '_' '{print $2}'`
                                        degrowNode="vhost\\_"$vhostId
                                    fi

            log "Degrow Node: $degrowNode"
            $BACKUPBINARY $BACKUPALLBINARY ${DegrowNodeCmd}${degrowNode}
        done
    fi
fi

#mcasid-11
#deleteNode , need update the count
if [ -f "$degrowActionFile" ]; then
        typeset groupInfo=`grep Aspect $scaleInfoFile`
        typeset groupName=`echo ${groupInfo%Aspect*}`

        log "groupInfo is $groupInfo, groupName is $groupName"

        typeset nodeName
        if [ -f $degrowSingleGroupFile ]; then
                nodeName="SI_NONPILOTSINGLE_GROUP_${groupName}_SCALING_COUNT"
        else
                nodeName="SI_NONPILOTVHOST_GROUP_${groupName}_SCALING_COUNT"
        fi

        log "NodeName is $nodeName"

        typeset totalCount=0
        totalCount=`grep $nodeName $countFile | awk -F '=' '{print $2}'`
        log "totalCount is $totalCount, nodeCount is $nodeCount"
        if [ $totalCount -eq 0 ]; then
                log "un-normal, the node count should be larger than 0"
                rm -f $degrowActionFile
                exit 1
        fi

        if [ $totalCount -lt $nodeCount ]; then
                log "totalCount[$totalCount] is smaller than scallling count[$nodeCount], shouldn't happen, exit"
                rm -f $degrowActionFile
                exit 1
        elif [ $totalCount -eq $nodeCount ]; then
                log "remove content[$nodeName] in $confFile"
                sed -i "/$nodeName/d" $countFile 
        else
                typeset curCount=`expr $totalCount - $nodeCount`
                sed -i "s/$nodeName=$totalCount/$nodeName=$curCount/g" $countFile
                log "update $nodeName's value from $totalCount to $curCount in $countFile"
  fi
        rm -f $degrowActionFile
fi



[[ -f $degrowSingleGroupFile ]] && rm -f $degrowSingleGroupFile
[[ -f $scaleInfoFile ]] && rm -f $scaleInfoFile
log "END SCALE POST ACTION SUCCESS!"
