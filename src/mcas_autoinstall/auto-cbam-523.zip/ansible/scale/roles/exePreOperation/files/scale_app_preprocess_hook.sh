# Application need add their sevices logic here itself
echo "----- scale_app_preprocess_hook.sh ======== have been called!!!==" >> /tmp/scale/scale_app_pre_hook.log