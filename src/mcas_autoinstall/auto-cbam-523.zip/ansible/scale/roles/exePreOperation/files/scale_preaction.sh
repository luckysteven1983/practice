#!/bin/sh

typeset tmpPath="/tmp/scale"
typeset appFile="/tmp/scale/scale_app_preprocess_hook.sh"
typeset cepFile="/tmp/scale/cepFileCmd_scale"
typeset prepareDegrowFile="/tmp/scale/prepareDegrowFile"
typeset vmIdFile="/tmp/scale/vmIdFile_scale_retiring.txt"
typeset statusFile="/tmp/scale/statusOfMachine"
typeset logFile="/tmp/scale_preaction_log"
typeset clientMap="/opt/config/conf/vm/client.map"
typeset subshl_cmd="/sn/cep/subshl"
typeset statusCmd="OP:STATUS, MACHINE=ALL"
typeset prepareDegrowCmd="BACKUP:PREPARE="
typeset confFile="/tmp/scale/conf.sh"
typeset confCmd="export CBAMSCALECONFIRM=1"
typeset degrowActionFile="/tmp/scale/degrow"
typeset degrowSingleGroupFile="/tmp/scale/single"
typeset BACKUPBINARY="/cs/sn/cr/cepexec"
typeset BACKUPALLBINARY="BACKUP_ALL"

typeset is_single=1
#degrowNodeList store like vhost_num
degrowNodeList=""
#degrowNodeList2 store like vhost-num
degrowNodeList2=""

if [ ! -d "$tmpPath" ]; then
    mkdir $tmpPath
fi

if [ -f "$confFile" ]; then
    rm -rf $confFile
    touch $confFile
fi

if [ -f "$logFile" ]; then
    rm -rf $logFile
    touch $logFile
fi

if [ -f "$degrowActionFile" ]; then
	rm -rf $degrowActionFile
fi

if [ -f "$degrowSingleGroupFile" ]; then
	rm -rf $degrowSingleGroupFile
fi

inArray(){
    for degrowNode in $degrowNodeList
    {
        if [ "$degrowNode" = "$1" ]; then 
            return 1
        fi
    }

    return 0
}

log(){
    echo $1 >> $logFile
}

log "BEGIN SCALE PRE ACTION!"

echo $confCmd >> $confFile
log "EXPORT CBAMSCALECONFIRM=1"
source $confFile


if [ -f "$prepareDegrowFile" ]; then
    rm -rf $prepareDegrowFile
    touch $prepareDegrowFile
fi

if [ ! -f "$vmIdFile" ]; then
    log "$vmIdFile not exist"
    unset CBAMSCALECONFIRM
    exit 1
fi

if [ -d "$tmpPath" ]; then
    if [ -f "$appFile" ]; then
        log "run scale_app_preprocess_hook.sh BEFORE "
        `/bin/sh $appFile`
        if [ $? != 0 ]; then
            log "scale_app_preprocess_hook.sh.sh run FAIL"
            unset CBAMSCALECONFIRM
            exit 1;
        fi
        log "run scale_app_preprocess_hook.sh.sh SUCCESS"
    fi
else
    log "no scale_app_preprocess_hook.sh.sh need run"
fi

#store the machine status using command "OP:STATUS, MACHINE=ALL" in subshl
`rm -rf $cepFile`
`rm -rf $statusFile`
echo $statusCmd >> $cepFile
$subshl_cmd -F $cepFile | while read statusInfo
do
    echo $statusInfo >>$statusFile
    log "-    $statusInfo"
done
log "Get machine status SUCCESS"

rcsList=""
log "MATCH vmId"
while read vmId 
do
    log "-    $vmId"
    result=`grep $vmId $clientMap`
    if [ $? -ne 0 ]; then
        log "vmId: $vmId not found in $clientMap"
        #unset CBAMSCALECONFIRM
        #exit 1
    else
    	rcs=`echo $result | awk '{print $1}'`
	/opt/config/bin/VnfcMap enabled && rcs=`/opt/config/bin/VnfcMap list | grep $rcs | awk '{print $2}'`
    	rcsList="$rcsList $rcs"
    fi

done < $vmIdFile

log "vmId match with clientMap SUCCESS"
log "rcsList need degrow"
log "-    $rcsList"
if [ "$rcsList" = "" ]; then
  log "no node need do PrepareDegrow"
  unset CBAMSCALECONFIRM
  exit 1
fi


VHOSTPATTERN="vhost-[0-9]+"
for rcs in $rcsList
do
    result=`grep $rcs $statusFile`
    if [ $? -ne 0 ]; then
        log "rcs: $rcs not found in machine status"
        unset CBAMSCALECONFIRM
        exit 1
    fi

    vhost_num=`echo $result | awk '{print $(NF-1)}'`
    degrowNodeList2="$degrowNodeList2 $rcs"

    if [[ $vhost_num =~ $VHOSTPATTERN ]]; then
        vhostId=`echo $vhost_num | awk -F '-' '{print $2}'`
        vhostStr="vhost\\_"$vhostId
        inArray $vhostStr
        ret=$?
	if [ $ret -eq 0 ]; then
            log "Need Degrow VHOST"
            log "-    $vhostStr"
            degrowNodeList="$degrowNodeList $vhostStr"
#            degrowNodeList2="$degrowNodeList2 $vhost_num"
			is_single=0
        fi
	
    else
        log "Need Degrow Single Node: "
        log "-    $rcs"
	/opt/config/bin/VnfcMap enabled && rcs=`/opt/config/bin/VnfcMap list | grep $rcs | awk '{print $1}'`
        degrowNodeList="$degrowNodeList $rcs"
#        degrowNodeList2="$degrowNodeList2 $rcs"
    fi
done
log "Get degrowNodeList:"
log "-    $degrowNodeList2"

# run prepareDegrowNode
log "PrepareDegrow BEGIN"
for degrowNode in $degrowNodeList
do
    count=0
    echo ${prepareDegrowCmd}${degrowNode} >> $prepareDegrowFile
    log "prepareDegrowNode: ${degrowNode}"
    $BACKUPBINARY $BACKUPALLBINARY ${prepareDegrowCmd}${degrowNode}
done
log "PrepareDegrow DONE"

log "Check machine status after PrepareDegrow BEGIN"
log "Get machine status before check"
`rm -rf $statusFile`
$subshl_cmd -F $cepFile | while read statusInfo
do
    echo $statusInfo >>$statusFile
    log "-    $statusInfo"
done
log "Get machine status before check DONE"

for degrowNode in $degrowNodeList2
do
    count=0
    while true
    do
        result=`grep $degrowNode $statusFile`
			
        curStatus=`echo $result | awk '{ print $2 }'`
		
        if [ "$curStatus" != "OFFLINE" ]; then
            count+=1
            sleep 30
            if [ $count > 3 ]; then
                log "NODE:"
                log "-    $degrowNode degrow FAIL"
                unset CBAMSCALECONFIRM
            		exit 1
        		fi
        else
            log "Node:"
            log "-    $degrowNode degrow SUCCESS"
            break
        fi
    done
done
log "Check machine status after PrepareDegrow END SUCCESS"

log "END SCALE PRE ACTION SUCCESS!"
`rm -rf $cepFile`
`rm -rf $statusFile`
`rm -rf $vmIdFile`
`rm -rf $confFile`
touch $degrowActionFile
[[ $is_single -eq 1 ]] && touch $degrowSingleGroupFile
unset CBAMSCALECONFIRM
exit 0
